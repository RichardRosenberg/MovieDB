package com.group4.movie.dto;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDto
{
    private Long id;
    @NotEmpty(message= "Username should not be empty")
    private String username;

    /*
    @NotEmpty(message = "Email should not be empty")
    @Email
    private String email;
    @NotEmpty(message = "Password should not be empty")
    private String password;
     */

    /**
     * Moji revisions
     * email should be valid
     * email must contain '.com' at the end
     */
    @NotEmpty(message = "Email should not be empty")
    @Email(message = "Invalid email format")
    @Pattern(regexp = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.com$", message = "Invalid email format")
    private String email;

    /**
     * Moji revisions
     * password should be mimnimum 6 characters long
     * password must contain at least 1 number and 1 capital letter
     */
    @NotEmpty(message = "Password should not be empty")
    @Size(min = 6, message = "Password should be at least 6 characters long")
    @Pattern(
            regexp = "^(?=.*[A-Z])(?=.*\\d).+$",
            message = "Password should contain at least one capital letter and one number"
    )
    private String password;

}