package com.group4.movie.util;

import com.group4.movie.entity.Role;
import com.group4.movie.entity.User;
import com.group4.movie.repository.RoleRepository;
import com.group4.movie.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;

/**
 * Moji revision
 * This class loads some preliminary data into the database.
 * It loads an admin user when application starts
 */
@Component
public class DataLoader implements CommandLineRunner {
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;

    public DataLoader(RoleRepository roleRepository, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.roleRepository = roleRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        /**
         * Moji revision
         *  add 'ÁDMIN_ROLE'
         */
        if(roleRepository.findByName("ROLE_ADMIN") == null) {
            Role adminRole = new Role();
            adminRole.setName("ROLE_ADMIN");
            roleRepository.save(adminRole);
        }

        /**
         * Moji revision
         *  add admin user with username 'moji'
         */
        User usr = userRepository.findByUsername("moji");
        //if user doesn't exist
        if(usr == null) {
            User user = new User();
            user.setUsername("moji");
            user.setEmail("moji@gmail.com");
            user.setPassword(passwordEncoder.encode("12345M"));
            Role role = roleRepository.findByName("ROLE_ADMIN");
            user.setRoles(Arrays.asList(role));
            userRepository.save(user);
        }
        /**
         * Moji revision
         * if user with username 'moji' already exists
         * you can update the other things : email, password
         */
        else {
            User userToBeUpdated = new User();
            userToBeUpdated.setId(usr.getId());
            userToBeUpdated.setUsername("moji");
            userToBeUpdated.setEmail("moji@gmail.com");
            userToBeUpdated.setPassword(passwordEncoder.encode("12345M"));
            Role role = roleRepository.findByName("ROLE_ADMIN");
            userToBeUpdated.setRoles(Arrays.asList(role));
            userRepository.save(userToBeUpdated);
        }
    }
}
